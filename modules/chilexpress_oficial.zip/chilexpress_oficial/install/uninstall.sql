DROP TABLE IF EXISTS `PREFIX_chilexpress_oficial_ordermeta`;
DROP TABLE IF EXISTS `PREFIX_chilexpress_oficial_apicache`;